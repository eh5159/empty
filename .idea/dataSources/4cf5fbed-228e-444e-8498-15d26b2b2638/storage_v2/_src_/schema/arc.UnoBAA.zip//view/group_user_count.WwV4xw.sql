create definer = areumchaeadmin@`%` view group_user_count as
select `arc`.`user`.`group_id` AS `group_id`, count(0) AS `user_count`
from `arc`.`user`
group by `arc`.`user`.`group_id`;

