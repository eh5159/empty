create definer = areumchaeadmin@`%` view view_orders_calculated_user_payment as
select `arc`.`orders`.`user_id` AS `user_id`, sum((`arc`.`orders`.`price` * `arc`.`orders`.`amount`)) AS `payment`
from `arc`.`orders`
where ((`arc`.`orders`.`day_calculate` = 'CALCULATED') and (`arc`.`orders`.`month_calculate` = 'CALCULATED'))
group by `arc`.`orders`.`user_id`;

