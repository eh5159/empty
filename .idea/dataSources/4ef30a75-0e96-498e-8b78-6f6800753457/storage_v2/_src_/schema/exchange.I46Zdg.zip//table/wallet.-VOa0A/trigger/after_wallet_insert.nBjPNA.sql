create definer = okbitdbmaster@`%` trigger after_wallet_insert
    after UPDATE
    on wallet
    for each row
BEGIN insert into wallet_log
  SET
    user_id = new.user_id
    , using_balance = new.using_balance
    , available_balance = new.available_balance
    , coin_name = new.coin_name
    ;
  END;

