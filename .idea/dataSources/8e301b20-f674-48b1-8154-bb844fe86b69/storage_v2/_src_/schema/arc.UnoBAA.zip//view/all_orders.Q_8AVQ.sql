create definer = sa@`%` view all_orders as
select `o`.`user_id`                     AS `user_id`,
       sum((`o`.`amount` * `o`.`price`)) AS `payment`,
       `u`.`level`                       AS `level`,
       `u`.`best_level`                  AS `best_level`,
       `u`.`exp`                         AS `exp`,
       `u`.`level_dt`                    AS `level_dt`,
       `u`.`group_id`                    AS `group_id`,
       `u`.`recom_id`                    AS `recom_id`,
       substr(`o`.`buy_dt`, 1, 7)        AS `buy_dt`
from (`arc`.`orders` `o`
         left join `arc`.`user` `u` on ((`o`.`user_id` = `u`.`id`)))
where (`o`.`month_calculate` = 'PENDING')
group by `o`.`user_id`, substr(`o`.`buy_dt`, 1, 7)
order by `o`.`user_id`;

