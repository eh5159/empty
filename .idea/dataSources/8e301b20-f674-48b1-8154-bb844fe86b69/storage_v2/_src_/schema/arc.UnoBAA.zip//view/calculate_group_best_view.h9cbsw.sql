create definer = sa@`%` view calculate_group_best_view as
select `ug`.`group_id` AS `group_id`, max(`ug`.`total_oney`) AS `total_oney`, `ug`.`id` AS `id`
from (select sum((`o`.`amount` * `o`.`price`)) AS `total_oney`, `u`.`id` AS `id`, `u`.`group_id` AS `group_id`
      from (`arc`.`orders` `o`
               left join `arc`.`user` `u` on ((`o`.`user_id` = `u`.`id`)))
      group by `u`.`id`
      order by `u`.`group_id`) `ug`
group by `ug`.`group_id`;

