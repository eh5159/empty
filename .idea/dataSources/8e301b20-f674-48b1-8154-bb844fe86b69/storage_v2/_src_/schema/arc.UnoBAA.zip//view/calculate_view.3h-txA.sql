create definer = sa@`%` view calculate_view as
select `cg`.`id`                AS `id`,
       `cg`.`group_name`        AS `group_name`,
       `guc`.`user_count`       AS `user_count`,
       `gtp`.`order_user_count` AS `order_user_count`,
       `goc`.`order_count`      AS `order_count`
from (((`arc`.`consumer_group` `cg` left join `arc`.`group_total_payment` `gtp` on ((`gtp`.`group_id` = `cg`.`id`))) left join `arc`.`group_user_count` `guc` on ((`guc`.`group_id` = `cg`.`id`)))
         left join `arc`.`group_order_count` `goc` on ((`goc`.`group_id` = `cg`.`id`)));

