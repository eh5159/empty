create definer = sa@`%` view user_info as
select `u`.`id`          AS `id`,
       `cg`.`id`         AS `group_id`,
       `cg`.`group_name` AS `group_name`,
       `u`.`user_name`   AS `user_name`,
       `u`.`level`       AS `level`,
       `u`.`recom_id`    AS `recom_id`,
       `u`.`cellphone`   AS `cellphone`,
       `u`.`reg_dt`      AS `reg_dt`
from (`arc`.`user` `u`
         left join `arc`.`consumer_group` `cg` on ((`u`.`group_id` = `cg`.`id`)))
order by `u`.`id`;

