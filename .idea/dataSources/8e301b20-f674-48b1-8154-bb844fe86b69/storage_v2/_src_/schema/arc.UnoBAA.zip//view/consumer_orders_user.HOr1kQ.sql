create definer = sa@`%` view consumer_orders_user as
select `o`.`id`                     AS `id`,
       `o`.`buy_dt`                 AS `buy_dt`,
       `o`.`user_id`                AS `user_id`,
       `u`.`group_id`               AS `group_id`,
       `u`.`level`                  AS `level`,
       `o`.`price`                  AS `price`,
       `o`.`amount`                 AS `amount`,
       (`o`.`amount` * `o`.`price`) AS `payment`,
       `o`.`month_calculate`        AS `month_calculate`
from (`arc`.`orders` `o`
         left join `arc`.`user` `u` on ((`o`.`user_id` = `u`.`id`)))
where (((`u`.`level` = 1) or (`u`.`level` = 2)) and (`o`.`month_calculate` = 'PENDING') and
       (`o`.`buy_dt` between '2020-04-01 00:00:00' and '2020-04-30 23:59:59'));

