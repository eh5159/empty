create definer = sa@`%` view consumer_orders_user_sum as
select `cou`.`group_id`       AS `group_id`,
       sum(`cou`.`payment`)   AS `sum_payment`,
       count(`cou`.`payment`) AS `count`,
       `cou`.`user_id`        AS `user_id`
from `arc`.`consumer_orders_user` `cou`
group by `cou`.`user_id`
order by `cou`.`group_id`, sum(`cou`.`payment`) desc;

