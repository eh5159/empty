create definer = sa@`%` view jabber_order_user as
select `o`.`user_id`                AS `user_id`,
       `u`.`group_id`               AS `group_id`,
       `u`.`level`                  AS `level`,
       `o`.`price`                  AS `price`,
       `o`.`amount`                 AS `amount`,
       (`o`.`price` * `o`.`amount`) AS `payment`,
       `o`.`buy_dt`                 AS `buy_dt`,
       `o`.`month_calculate`        AS `month_calculate`
from (`arc`.`orders` `o`
         left join `arc`.`user` `u` on ((`o`.`user_id` = `u`.`id`)))
where (`u`.`level` = 4);

