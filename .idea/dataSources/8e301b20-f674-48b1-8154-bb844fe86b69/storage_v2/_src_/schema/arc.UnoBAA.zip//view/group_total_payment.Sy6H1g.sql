create definer = sa@`%` view group_total_payment as
select `consumer_orders_user_sum`.`group_id`         AS `group_id`,
       sum(`consumer_orders_user_sum`.`sum_payment`) AS `sum_sum_payment`,
       count(`consumer_orders_user_sum`.`user_id`)   AS `order_user_count`
from `arc`.`consumer_orders_user_sum`
group by `consumer_orders_user_sum`.`group_id`;

