create definer = sa@`%` view consumer_best_pament as
select `consumer_orders_user_sum`.`group_id`         AS `group_id`,
       max(`consumer_orders_user_sum`.`sum_payment`) AS `max_payment`
from `arc`.`consumer_orders_user_sum`
group by `consumer_orders_user_sum`.`group_id`;

