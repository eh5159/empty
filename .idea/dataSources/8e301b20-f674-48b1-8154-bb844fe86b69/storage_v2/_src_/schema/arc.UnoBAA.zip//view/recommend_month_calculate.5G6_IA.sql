create definer = sa@`%` view recommend_month_calculate as
select `u`.`recom_id`              AS `recom_id`,
       substr(`u`.`reg_dt`, 1, 7)  AS `reg_dt`,
       count(0)                    AS `count`,
       sum(`ao`.`payment`)         AS `payment`,
       substr(`ao`.`buy_dt`, 1, 7) AS `buy_dt`
from (`arc`.`user` `u`
         left join `arc`.`all_orders` `ao` on ((`ao`.`user_id` = `u`.`id`)))
where (`u`.`recom_id` is not null)
group by `u`.`recom_id`, substr(`u`.`reg_dt`, 1, 7)
order by `u`.`recom_id`;

