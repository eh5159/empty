create definer = sa@`%` view group_order_count as
select `consumer_orders_user`.`group_id` AS `group_id`, count(`consumer_orders_user`.`user_id`) AS `order_count`
from `arc`.`consumer_orders_user`
group by `consumer_orders_user`.`group_id`
order by `consumer_orders_user`.`group_id`;

