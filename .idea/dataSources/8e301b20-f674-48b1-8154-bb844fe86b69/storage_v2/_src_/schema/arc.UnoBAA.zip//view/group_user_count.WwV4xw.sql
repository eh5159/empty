create definer = sa@`%` view group_user_count as
select `arc`.`user`.`group_id` AS `group_id`, count(`arc`.`user`.`id`) AS `user_count`
from `arc`.`user`
where ((`arc`.`user`.`level` = 1) or (`arc`.`user`.`level` = 2))
group by `arc`.`user`.`group_id`;

