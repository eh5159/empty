create definer = sa@`%` view user_view as
select `u`.`id`          AS `id`,
       `u`.`group_id`    AS `group_id`,
       `cg`.`group_name` AS `group_name`,
       `u`.`level`       AS `level`,
       `u`.`cellphone`   AS `cellphone`,
       `u`.`user_name`   AS `user_name`
from (`arc`.`user` `u`
         left join `arc`.`consumer_group` `cg` on ((`u`.`group_id` = `cg`.`id`)));

